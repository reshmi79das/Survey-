package com.qa.surveymonkey.utils;

public class Constants {
	
	public static final String LOGIN_PAGE_TITLE = "Log in to your account";
	public static final String HOME_PAGE_TITLE = "Welcome to SurveyMonkey!";
	public static final String DASHBOARD_LINK = "Dashboard";
	public static final String MYSURVEYS_LINK = "My Surveys";

}
